from mangum.adapter import Mangum

__all__ = ["Mangum"]
